package com.APITickets.API_Tickets.enums;

public enum CategoryTicket {
    Tecnique,
    Théorique,
    pratique,
    }