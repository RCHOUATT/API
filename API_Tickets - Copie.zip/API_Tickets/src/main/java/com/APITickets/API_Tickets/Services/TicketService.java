package com.APITickets.API_Tickets.Services;

import com.APITickets.API_Tickets.Module.Ticket;

import java.util.List;

public interface TicketService {

    Ticket Create(Ticket ticket);

    List<Ticket> Afficher();

    String Supprimer(Long Id);

    Ticket Update(Long id, Ticket ticket);
}