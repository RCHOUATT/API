package com.APITickets.API_Tickets.Controller;


import com.APITickets.API_Tickets.Module.Ticket;
import com.APITickets.API_Tickets.Services.TicketServiceImplement;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@AllArgsConstructor
@RestController
@RequestMapping("ticket")
public class TicketController {

    private TicketServiceImplement TicketService;

    @PostMapping("/Ajout")
    public Ticket save(@RequestBody Ticket ticket){
       return TicketService.Create(ticket);
    }


}
