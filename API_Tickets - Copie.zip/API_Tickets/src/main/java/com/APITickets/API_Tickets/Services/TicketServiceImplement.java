package com.APITickets.API_Tickets.Services;

import com.APITickets.API_Tickets.Module.Ticket;
import com.APITickets.API_Tickets.Repository.Ticket_repository;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.stereotype.Service;



import java.util.List;

@AllArgsConstructor
@Service
@Data
public class TicketServiceImplement implements TicketService {

    private Ticket_repository ticketRepository;

    @Override
    public Ticket Create(Ticket ticket) {
        return ticketRepository.save(ticket);
    }

    @Override
    public List<Ticket> Afficher() {
        return ticketRepository.findAll();
    }

    @Override
    public String Supprimer(Long Id) {
        ticketRepository.deleteById(Id);
        return "Ticket " + Id + " Ticket avec succès";
    }

    @Override
    public Ticket Update(Long id, Ticket ticket) {
        return ticketRepository.findById(id)
                    .map(p -> {
                        p.setTitre(ticket.getTitre());
                        p.setDescription(ticket.getDescription());
                        p.setStatus(ticket.getStatus());
                        return ticketRepository.save(p);
                    }).orElseThrow(() -> new RuntimeException("Ticket " + id + " non trouvé" ));
    }
}