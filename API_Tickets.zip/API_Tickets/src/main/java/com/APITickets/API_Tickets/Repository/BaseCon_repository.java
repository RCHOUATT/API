package com.APITickets.API_Tickets.Repository;

import com.APITickets.API_Tickets.Module.BaseDeConnaissance;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BaseCon_repository extends JpaRepository<BaseDeConnaissance, Long>{
}
