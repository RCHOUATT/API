package com.APITickets.API_Tickets.enums;

public enum TypeStatus {
    TEST,
    YES,
    NON
}
