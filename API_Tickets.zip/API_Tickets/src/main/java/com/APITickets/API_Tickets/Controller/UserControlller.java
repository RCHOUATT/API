package com.APITickets.API_Tickets.Controller;


import com.APITickets.API_Tickets.Module.Utilisateurs;
import com.APITickets.API_Tickets.Services.UserService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("User")
public class UserControlller {

    private UserService userService;

    @PostMapping("/Ajout")
    public Utilisateurs Creer(@RequestBody Utilisateurs user) {
        return userService.CreerUser(user);
    }

    @GetMapping("/Afficher")
    public List<Utilisateurs> Afficher() {
        return userService.AfficherUser();
    }

    ;

    @DeleteMapping("/Supprimer/{id}")
    public String supprimer(@PathVariable Long Id) {
        return userService.SupUser(id);
    }

    ;

    @PutMapping("/update/{id}")
    public public Utilisateurs updateUser(Long id, Utilisateurs user) {
        return userService.UpdateUser(id, user);
    }
}
