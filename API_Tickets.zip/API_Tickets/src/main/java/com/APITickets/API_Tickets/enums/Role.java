package com.APITickets.API_Tickets.enums;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public enum Role {
    Admin,
    Apprenant,
    Formateur,
}
