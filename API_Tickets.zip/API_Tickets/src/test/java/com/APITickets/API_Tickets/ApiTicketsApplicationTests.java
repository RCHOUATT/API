package com.APITickets.API_Tickets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTicketsApplicationTests {

	@Test
	void contextLoads() {
	}

}
